/*
	GetIt Package Manager IDE Automation 
*/

var getItServiceName = "getit";

/*
	Function: getGetItService.
	Description: 
		- Gets the service object used to interact with the IDE.
		- If GetIt.bpl is not installed on the IDE side, funcion will return a null value.
	Output: Object.
*/
function getGetItService() {
	try {
		if ((typeof external.application != "undefined") && (typeof external.application != "null")) {
			return external.application.GetService(getItServiceName);
		} else {
			return null;
		}
	} catch(e) {
		return null;
	}	
}

/*
	Function: systemPackageManagerAvailable.
	Description: GetIt System Package Manager availability.
	Output:
		Boolean. Returns a true if GetIt System Package Manager is available or not.
*/
function systemPackageManagerAvailable() {
	var srv = getGetItService();
	
	if (typeof srv != "null") {
		return srv.SystemPackageManagerAvailable();
	} else {
		return false;
	}
}

/*
	Function: showSystemPackageManager.
	Description: 
		- Shows GetIt System Package Manager. 
		- This function must be used in combination with "systemPackageManagerAvailable" to know
		if it is possible to show the GetIt System Package Manager. 
	Output:
		Boolean. Returns a true when success.
*/
function showSystemPackageManager() {
	var srv = getGetItService();
	
	if (typeof srv != "null") {
		srv.ShowSystemPackageManager();
		return true;
	} else {
		return false;
	}
}

/*
	Function: showPackageManager.
	Description: Show GetIt Platform Manager.
	Output:
		Boolean. Returns a true when success.
*/
function showPackageManager() {
	var srv = getGetItService();
	
	if (typeof srv != "null") {
		srv.ShowPackageManager();
		return true;
	} else {
		return false;
	}
}

/*
	Function: getPackageList.
	Description: Gets the list of the sample applications.
	Output: Returns the list of the sample applications if the list is not empty after first call. If the list is empty or null,
		tries to retrieve the list after every 2 secs, and eventually displays the list. 
*/
function getPackageList() {	
	var srv = getGetItService();
	var packageList;
	if (typeof srv != "null") {
		packageList = srv.GetPackageList();
		if (!packageList) {
			var id = setInterval(function(){
				packageList = srv.GetPackageList();
				if (packageList) {
					renderSampleApps(packageList);
					clearInterval(id);			
				}
			}, 2000);
		}	
	}
	return packageList;
}

/*
	Function: loadPackageList.
	Description: Starts the thread which loads the sample applications from Getit server.
*/
function loadPackageList() {
	var srv = getGetItService();
	var packageList = '';
	if (typeof srv != "null") {
		srv.LoadPackageList();	
	} 
}

/*
	Function: getItemLocation.
	Description: Gets the location of the sample application.
	Output: Returns the location of the Item if installed, otherwise 'NotInstalled' string is returned.
*/
function getItemLocation(id) {	
	var srv = getGetItService();
	if (typeof srv != "null") {
		return srv.GetItemLocation(id);			
	}
}

/*
	Function: installItem.
	Description: Installs the application from introductory samples category.
*/
function installItem(id) {	
	var srv = getGetItService();
	if (typeof srv != "null") {
		srv.InstallItem(id);	
	} 
}
