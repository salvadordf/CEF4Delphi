/*
	BIDE-4 IDE Walkthrough Technology (Guided Tour)
*/

var tutorialTimer = null;
var tutorialDelay = 1000;
var tutorialServiceName = "guidedtour";
var defaultJsActionDelay = 1000;

/*
	Function: getTutorialService.
	Description: Gets the service object used to interact with the IDE.
	Output: Object.
*/
function getTutorialService() {
	try {
		if ((typeof external.application != "undefined") && (typeof external.application != "null")) {
			return external.application.GetService(tutorialServiceName);
		} else {
			return null;
		}
	} catch(e) {
		return null;
	}	
}

/*
	Function: addToolTip.
	Description: Shows a bubble at a position.
	Parameters:
		- componentName: String. Name of the form plus a dot and a name of the component. 
			It is possible to specify only a form name.
		- actionName: String. Name of the action. We can specify a name of an action in order to search a 
			component inside his container (parameter "componentName").
		- position: Could be an array of integer or a string. Position is calculated using it�s container (parameter "componentName"). 
				- Array case: Coordinate where position[0] = X and position[1] = Y. 
					The array could be empty (position = []) if we don�t want to specify a position.
				- String case: Position desired. The string could be empty (position = "") if we don�t want to specify a position.
					Available positions:
						- "center": Shows a bubble at a centered position relative to it�s container (parameter "componentName").  
						- "topcenter": Shows a bubble at position top-center relative to it�s container (parameter "componentName").  
						- "topright": Shows a bubble at position top-right relative to it�s container (parameter "componentName").  
						- "topleft": Shows a bubble at position top-left relative to it�s container (parameter "componentName").  
						- "leftcenter": Shows a bubble at position left-center relative to it�s container (parameter "componentName").  
						- "rightcenter": Shows a bubble at position right-center relative to it�s container (parameter "componentName").  
						- "bottomleft": Shows a bubble at position bottom-left relative to it�s container (parameter "componentName").  
						- "bottomcenter": Shows a bubble at position bottom-center relative to it�s container (parameter "componentName").  
						- "bottomright": Shows a bubble at position bottom-right relative to it�s container (parameter "componentName").  
			Important: Parameter "actionName" is not supported using this parameter. 
		- title: String. Title of the bubble.
		- text: String. Text of the bubble.
		- visibilityTime: Integer. Visibility time of the bubble in milliseconds. 
			If value is equal to 0, the bubble won�t disappear automatically.
		- showContinueLink: Boolean. Shows/Hides a link to give to the user the possibility to continue the tutorial when clicking on it.
		- balloonStyle. Boolean. Shows or not the bubble like a balloon (with the pointer).
	Output:
		Boolean. Returns true if the bubble has been added.
*/
function addToolTip(componentName, actionName, position, title, text, visibilityTime, showContinueLink, balloonStyle) {
	var service = getTutorialService();

	if (typeof service != "null") {
		if (((typeof position != "string") && (position.length == 0)) || ((typeof position == "string") && (position == ""))) {
			if (actionName == "") {
				return service.AddToolTip(componentName, title, text, visibilityTime, showContinueLink, balloonStyle);
			} else {
				return service.AddToolTipByAction(componentName, actionName, title, text, visibilityTime, showContinueLink, balloonStyle);
			}
		} else {
			if (typeof position != "string") {
				return service.AddToolTipByCoords(componentName, position[0], position[1], title, text, visibilityTime, showContinueLink, balloonStyle);
			} else {
				return service.AddToolTipByPosition(componentName, position, title, text, visibilityTime, showContinueLink, balloonStyle);
			}
		}
	} else {
		return false;
	}
}

/*
	Function: isToolTipVisible.
	Description: Gives information about the visibility of a specified bubble.
	Parameters:
		- componentName: String. Name of the form plus a dot and a name of the component. 
			It is possible to specify only a form name. 
	Output:
		Boolean. Returns true if the bubble his visible.
*/
function isToolTipVisible(componentName) {
	var service = getTutorialService();

	if (typeof service != "null") {
		return service.IsToolTipVisible(componentName);
	} else {
		return false;
	}
}

/*
	Function: isWindowVisible.
	Description: Gives information about the visibility of a specified form.
	Parameters:
		- windowName: String. Name of the form. 
	Output:
		Boolean. Returns true if the form his visible.
*/
function isWindowVisible(windowName) {
	var service = getTutorialService();

	if (typeof service != "null") {
		return service.IsWindowVisible(windowName);
	} else {
		return false;
	}
}

/*
	Function: deleteToolTip.
	Description: Deletes a specified bubble.
	Parameters:
		- componentName: String. Name of the form plus a dot and a name of the component. 
			It is possible to specify only a form name. 
	Output:
		Boolean. Returns true if the bubble has been deleted.
*/
function deleteToolTip(componentName) {
	var service = getTutorialService();

	if (typeof service != "null") {
		return service.DeleteToolTip(componentName);
	} else {
		return false;
	}
}

/*
	Function: deleteToolTips.
	Description: Deletes all the bubbles.
	Parameters: No parameters.
	Output: No output.
*/
function deleteToolTips() {
	var service = getTutorialService();

	if (typeof service != "null") {
		service.DeleteToolTips();
	} else {
		return false;
	}
}

/*
	Function: componentFromForm.
	Description: Search and return a Form/Component.
	Parameters: 
		- name: string. Name of the form plus a dot and the component name.
		  It is possible to specify only a form name.
	Output: Component.
*/
function componentFromForm(name) {
	var service = getTutorialService();

	if (typeof service != "null") {
		return service.ComponentFromForm(name);
	} else {
		return null;
	}
}

/*
	Function: componentFromAction.
	Description: Search and return a Form/Component by his action.
	Parameters: 
		- componentName: string. Name of the form plus a dot and a name of the component. 
		  It is possible to specify only a form name.
		- actionName: string. Name of the action. We can specify a name of an action in order to search a 
		  component inside his container
	Output: Component.
*/
function componentFromAction(componentName, actionName) {
	var service = getTutorialService();

	if (typeof service != "null") {
		return service.ComponentFromAction(componentName, actionName);
	} else {
		return null;
	}
}

/*
	Function: sendKeys.
	Description: Send keys.
	Parameters: 
		- keys: string. Keys characters to send or key code (for special keys).
		- specialKeys: Boolean. Specify if the first parameter will be the code of an special key or not.
		  Special keys codes.
			'ESC', 'DEL', 'ENTER', 'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11',
			'F12', 'BKSP', 'BREAK', 'CAPSLOCK', 'CLEAR', 'HELP', 'HOME', 'INS', 'NUMLOCK', 'NEXT', 
			'PRIOR', 'END', 'PRINT', 'UP', 'LEFT', 'RIGHT', 'DOWN', 'TAB'.
		- times: Integer. Specify how many times it will send the keys string.
	Output: No output.
*/
function sendKeys(keys, specialKeys, times) {
	var service = getTutorialService();

	if (typeof service != "null") {
		service.SendKeys(keys, specialKeys, times);
	} 
}

/*
	Function: runJsAction.
	Description: Run a Javascript string code.
	Parameters: 
		- jsActionTxt: string. Javascript code.
		- timeOut: integer. Delay time in milliseconds to start running the Javascript.
			If timeOut is null, the default value will be the value defined for the constant defaultJsActionDelay.
	Output: No output.
*/
function runJsAction(jsActionTxt, timeOut) {
	if ((typeof jsActionTxt != "undefined") && (typeof jsActionTxt != "null") && 
			(typeof jsActionTxt == "string")) {
		
		if ((typeof timeOut == "undefined") || (typeof timeOut == "null"))
			var timeOut = defaultJsActionDelay;
			
		if (jsActionTxt != "") {
			window.setTimeout(function() {
				try {
					eval(jsActionTxt);
				} catch(e) {
					alert(e.message);
				}
			}, timeOut);
		}
	}
}

/*
	Function: canContinueTutorial.
	Description: Returns if the IDE main form is available or not for continue with the tutorial.
	Parameters: no parameters.
	Output: Boolean.
*/
function canContinueTutorial() {
	try {
		if ((typeof external.application != "undefined") && (typeof external.application != "null")) {
			return (isWindowVisible(external.application.MainForm.Name) && (!external.application.MainForm.WinStateMinimized));
		} else {
			return false;
		}
	} catch(e) {
		return false;
	}	
}

/*
	Function: stopTutorial.
	Description: Stops the interactive tutorial.
	Parameters: No parameters.
	Output: No output.
*/
function stopTutorial() {
	if ((typeof tutorialTimer != "undefined") && (typeof tutorialTimer != "null"))
		window.clearInterval(tutorialTimer);
	
	tutorialTimer = null;
	deleteToolTips();
}

/*
	Function: startTutorial.
	Description: Starts the interactive tutorial.
	Parameters: 
		- toolTips: Array of step. step is an array of the following type:
				step[0] = componentName. String. Name of the form plus a dot and a name of the component. 
					It is possible to specify only a form name. 
				step[1] = actionName. String. Name of the action. We can specify a name of an action in order to search a 
					component inside his container (parameter step[0]). 
				step[2] = position: Could be an array of integer or a string. Position is calculated using it�s container (parameter "componentName"). 
					- Array case: Coordinate where position[0] = X and position[1] = Y. 
						The array could be empty (position = []) if we don�t want to specify a position.
					- String case: Position desired. The string could be empty (position = "") if we don�t want to specify a position.
						Available positions:
							- "center": Shows a bubble at a centered position relative to it�s container (parameter "componentName").  
							- "topcenter": Shows a bubble at position top-center relative to it�s container (parameter "componentName").  
							- "topright": Shows a bubble at position top-right relative to it�s container (parameter "componentName").  
							- "topleft": Shows a bubble at position top-left relative to it�s container (parameter "componentName").  
							- "leftcenter": Shows a bubble at position left-center relative to it�s container (parameter "componentName").  
							- "rightcenter": Shows a bubble at position right-center relative to it�s container (parameter "componentName").  
							- "bottomleft": Shows a bubble at position bottom-left relative to it�s container (parameter "componentName").  
							- "bottomcenter": Shows a bubble at position bottom-center relative to it�s container (parameter "componentName").  
							- "bottomright": Shows a bubble at position bottom-right relative to it�s container (parameter "componentName").  
					Important: Parameter "actionName" is not supported using this parameter. 
				step[3] = title. String. Title of the bubble.
				step[4] = text. String. Text of the bubble.
				step[5] = visibilityTime. Integer. Visibility time of the bubble in milliseconds. If value is equal to 0, 
					the bubble won�t disappear automatically.
				step[6] = showContinueLink. Boolean. Shows/Hides a link to give to the user the possibility to continue 
					the tutorial when clicking on it. 
				step[7] = checkCondition. Array. It specifies a condition to hide the bubble.
					The array has the following format: 
						checkCondition[0] = String. Form name to check.
						checkCondition[1] = Boolean. Visibility of the form to check.
					The array could be empty (checkCondition = []) if we don�t want to specify a condition.
				step[8] = balloonStyle. Boolean. Shows or not the bubble like a balloon (with the pointer).
				step[9] = jsAction: String. Run a javascript. If visibilityTime is different than 0, the script will start after this time. 
					If visibilityTime is equal to 0, the script will start after the default time (defined in constant defaultJsActionDelay). 
	Output: No output.
*/
function startTutorial(steps) {
	var Added = false; 
	
	stopTutorial();
	
	if ((typeof steps != "undefined") && (typeof steps != "null") && 
			(typeof steps != "string") && (steps.length > 0)) {
		tutorialTimer = window.setInterval(function() {
			try { 
				if (steps.length > 0) {
					var step = steps[0]; 
					
					var componentName = step[0];
					var actionName = step[1];
					var position = step[2];
					var title = step[3];
					var text = step[4];
					var visibilityTime = step[5];
					var showContinueLink = step[6];
					var checkCondition = step[7];
					var balloonStyle = step[8];
					var jsAction = step[9];
					
					if (canContinueTutorial()) {
						if (!Added) { 
							Added = addToolTip(componentName, actionName, position, title, text, visibilityTime, showContinueLink, balloonStyle);
							
							if ((Added) && (visibilityTime == 0))
								runJsAction(jsAction);
							
						} else if (!isToolTipVisible(componentName)) {				
							Added = false;
							steps.shift();
							
							if (visibilityTime > 0)
								runJsAction(jsAction, 0);
								
						} else if ((checkCondition.length > 0) && isToolTipVisible(componentName)) {		
							if (isWindowVisible(checkCondition[0]) == checkCondition[1]) {
								Added = false;
								deleteToolTip(componentName);
								steps.shift();
							}
						} else if (isToolTipVisible(componentName) && (!isWindowVisible(componentName))) {
							stopTutorial();
						}
					}
				} else {
					stopTutorial();
				}
			} catch(e) {
				alert(e.message);
				stopTutorial();
			}
		}, tutorialDelay);
	}
}

window.onunload = window.onunload || function() {
	stopTutorial();
};