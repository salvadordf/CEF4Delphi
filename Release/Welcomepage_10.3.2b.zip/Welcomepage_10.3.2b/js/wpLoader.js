var clientIsOnline = false;
var clientIsOnlineXml;
var clientUsesProxy;
var clientProxyString;
var clientProxyUser;
var clientProxyPassword;
var clientAppDataFolder;
var appPath;
var wpPath;
var xmlPath;
var xslPath;
var xmlPersonal;
var nodeSettings;
var nodeLanguage;
var UILanguages;

function debugAlert(msg) {
	getNotification(false).text = msg;
	displayNotification();
}

var classHide = 'wuppdi';
var regHide = /\s*wuppdi/;

function showWait() {
	var c = Working.className;
	Working.className = (c == classHide)?"doShow" : c + " doShow";
}

function hideWait() {
	var regShow = /\s*doShow/;
	var c = Working.className;
	c = (c)?c.replace(regShow, "") : "";
	Working.className = (c == "")?classHide : c;
}

function getLangString(name) {
    var node;

    node = nodeLanguage.selectSingleNode('*[@name="' + name + '"]');
    if (node != null) {
        return node.text
    }
}

function setElementText(elementId, textId) {
    var el;

    el = document.getElementById(elementId);
    if (el != null) {
      el.innerHTML = getLangString(textId);
    }
}

function initializeWP() {
	try {
		loadSettings();
		initializeLanguageData();

		registerNotificationLinks();
		registerProjectLinks();
		registerRssLinks();
		registerOrLinks();

		loadMenus();
		loadProjectsList();
		loadMyFavoritesList();
		updatePageLayout();

		menuGuidCall('');
	} catch(e) {
		debugAlert('initializeWP: ' + e.message);
	}
	hideWait();
}

function loadSettings() {
	try {
		// initialize application variables
		clientIsOnline = true;
		clientUsesProxy = external.Application.UsesProxy;
		clientProxyString = external.Application.ProxyString;
		clientUserAgentString = external.Application.UserAgent;
		clientAppDataFolder = external.Application.AppDataFolder;
		clientProxyUser = '';
		clientProxyPassword = '';
		
		// determine path variables
		appPath = external.Application.ExeName;
		appPath = appPath.substr(0, appPath.lastIndexOf('\\'));
		appPath = appPath.substr(0, appPath.lastIndexOf('\\') + 1);
		wpPath = appPath + 'WelcomePage\\';
		xmlPath = wpPath + 'XML\\';
		xslPath = wpPath + 'XSL\\';

		// Delimitter is , UILanguages is languages string array.
		UILanguages = external.Application.PreferredUILanguages.split(',');
		
		// load settings
		xmlPersonal = loadXmlDocSafe(clientAppDataFolder + '\\welcomePage.xml');
		nodeSettings = getSubNode(xmlPersonal.documentElement, 'settingsEx');
	} catch(e) {
		debugAlert("loadSettings: " + e.message);
	}
}

function initializeLanguageData() {
	// load language data
	nodeLanguage = loadXmlDocSafe('bds:/xsl/languageStrings.xsl').documentElement;
	
	setElementText('pageCopyright', 'pageCopyright');
	setElementText('pageReportPiracy', 'pageReportPiracy');
	setElementText('pageLegalNotices', 'pageLegalNotices');
	setElementText('pagePrivacyPolicy', 'pagePrivacyPolicy');
	setElementText('Working', 'pageWorking');
}

function savePersonalSettings()
{
	var settingsFile;

	settingsFile = clientAppDataFolder + '\\welcomePage.xml';
	xmlPersonal.save(settingsFile);
}

function updatePageLayout() {
	Content.style.pixelHeight = document.body.clientHeight - 155;
	ContentArea.style.pixelHeight = Content.style.pixelHeight - ContentHeader.style.pixelHeight - 24;
}

function prepareStartHerePageLayout()
{
	menuBarGroup = document.getElementById('menuBarGroup');

	if (menuBarGroup != null) 
	{
		menuBarGroup.style.display = 'none';
	    Content.style.paddingLeft = '5px';
		ContentArea.style.left = '6px';
		ContentHeader.style.left = ContentArea.style.left;
		ContentHeader.innerHTML = '<table align="left"><tr><td class="contentHeadline">'+getLangString('startHere')+'<span id="blogTitle"></span></td></tr></table>';
		ContentArea.innerHTML = '';		
	}
}

function loadStartHerePage()
{
	// The height of the frame is determined by the height of the image used for pinging the server
	// This image should be resized accordingly to the height of the Start Here page contents, because the height cannot
	// be fetch programmatically due cross-domain issues and don't want to place hacks which may lead to browser issues.
	pageheight=img.height;
	delete img;
	online = true;
	prepareStartHerePageLayout();	
	ContentArea.innerHTML = '<iframe id="videoframe" height="'+pageheight+'" width="100%" src="'+getLangString('startPageHostURL')+getLangString('startPageIndex')+'"></iframe>';
}

function loadStartHereErrorPage()
{
	delete img;
	if (!online)
	{
		prepareStartHerePageLayout();	
		ContentArea.innerHTML = '<br /><br /><br /><br /><p style="text-align: center; padding: 5px; color:#545454; width:100%;  margin:5px auto;background-color: #ffcdd1; border-top: 2px solid #e10c0c; border-bottom: 2px solid #e10c0c; font-weight: bold;">'+getLangString('startPageCannotAccess')+'<br/><br/>'+getLangString('startPagePleaseConnect')+'</p>';
	}
}

function showStartHerePage() {
	prepareStartHerePageLayout();

	online = false;
	
	delete img;
	
	img = new Image();

    img.onload = loadStartHerePage;
	
    img.onerror = loadStartHereErrorPage;

	img.src=getLangString('startPageHostURL')+getLangString('startPagePing')+'?cachebreaker='+new Date().getTime();
	this.timer = setTimeout(function() {loadStartHereErrorPage();}, 3000);

}

function clearElementContent(element) {
	while (element.childNodes.length != 0)
	{
		element.removeChild(element.childNodes[0]);
	}
}

function setClientIsOnline(e) {
	if (e != clientIsOnline) {
		if (!e) {
            try {
    			clientIsOnlineXml = getNotification(true);
	    		clientIsOnlineXml.text = getLangString('stateOffline');
		    	displayNotification();
            } catch(e) {
                alert(e.message);
            }
		} else {
			removeNotification(clientIsOnlineXml);
		}
		clientIsOnline = e;
	}
}

function GetLocaleFile(BasePath, FileName) {
	fso = new ActiveXObject("Scripting.FileSystemObject");
	var s, i;
	for (i = 0; i < UILanguages.length; i++)
	{
		s = BasePath + UILanguages[i] + '\\' + FileName;
		if (fso.FileExists(s))
			return s;
	}
	return BasePath + FileName;
}